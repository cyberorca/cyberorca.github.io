/*
	structure
	1 #kly-adons-main-wrapper
		1.1 #kly-adons-open
			1.1.1 #img dolphin

		1.2 .header
			1.2.1 h1 title
			1.2.2 input --> search
			1.2.3 #kly-adons-minimize

		1.3 body
			1.3.1 kly-adons-data
				1.3.1.1 .list
				1.3.1.2 .scroll-down
					i fas fa angle
			1.3.2 kly-adons-date-selected

		1.4 footer
			1.4.1 dmp-tracker-status
				1.4.1.1 success
				1.4.1.2 error
			1.4.2 dmp-wrapper
				1.4.2.1 kly-adons-copy
				1.4.2.2 kly-adons-apply


				*/

// #1 
// create main wrapper 
var _siInjected = document.getElementById("kly-adons-main-wrapper");

var _mainWrapper = document.createElement("div");
_mainWrapper.setAttribute("id", "kly-adons-main-wrapper");
_mainWrapper.setAttribute("class", "t5");

//inject main wrapper 
if (!_siInjected) {
	document.body.appendChild(_mainWrapper);
}

// #1.1 
// create open button 
var _openBtn = document.createElement("div");
_openBtn.setAttribute("id", "kly-adons-open");
// append button to mai warapper
_mainWrapper.appendChild(_openBtn);

//#1.1.1
// crate img open button
var _imgOpen = document.createElement("img");
_imgOpen.setAttribute("src", chrome.runtime.getURL("img/icon.png"));
_openBtn.appendChild(_imgOpen);

//#1.2
// create header section for popup
var _header = document.createElement("div");
_header.setAttribute("class", "header");
// append to main wrapper 
_mainWrapper.appendChild(_header);

//#1.2.1
//crate title header
var _title = document.createElement("h1");
_title.setAttribute("class", "title");
_title.textContent = "DMP ";
_header.appendChild(_title);

//create title span
var _titleSpan = document.createElement("span");
_titleSpan.textContent = "Tracker";
_title.appendChild(_titleSpan);

//#1.2.2
// create search 
var _filterWrapper = document.createElement("div");
_filterWrapper.setAttribute("id", "kly-adons-filter-wrapper");
_header.appendChild(_filterWrapper);

var _select = document.createElement("select");
_select.setAttribute("type", "text");
_select.setAttribute("id", "kly-adons-select");
_select.setAttribute("class", "search");
_filterWrapper.appendChild(_select);

var _search = document.createElement("input");
_search.setAttribute("type", "text");
_search.setAttribute("id", "kly-adons-search");
_search.setAttribute("class", "search");
_search.setAttribute("placeholder", "search....");
_filterWrapper.appendChild(_search);

//#1.2.3
// create minimize button on header 
var _minimize = document.createElement("div");
_minimize.setAttribute("id", "kly-adons-minimize");
_header.appendChild(_minimize);
// create icon minimize
var _closeX = document.createElement("i");
_closeX.setAttribute("class", "fas fa-times");
_minimize.appendChild(_closeX);

//#1.3
// create body container popup

var _body = document.createElement("div");
_body.setAttribute("id", "kly-adons-body-content");
_body.setAttribute("class", "body");
_mainWrapper.appendChild(_body);


//1.3.1
// create list wrapper
var _fetchDtaWrapper = document.createElement("div");
_fetchDtaWrapper.setAttribute("id", "kly-adons-data");
_body.appendChild(_fetchDtaWrapper);

var _btnReload = document.createElement("button");
_btnReload.setAttribute("id", "kly-button-reload-dmp-api");
_btnReload.textContent = "reload dmp tracker";
_fetchDtaWrapper.appendChild(_btnReload);

//#1.3.1.1
// create list container
var _listData = document.createElement("ul");
_listData.setAttribute("class", "list");
_fetchDtaWrapper.appendChild(_listData);

//1.3.1.2
// create scroll sign , animate up down
var _scroll = document.createElement("div");
_scroll.setAttribute("class", "scroll-down");
_scroll.textContent = "scroll ";
_fetchDtaWrapper.appendChild(_scroll);
//create scroll arror icon
var _scrollArrow = document.createElement("i");
_scrollArrow.setAttribute("class", "fas fa-angle-double-right");
_scroll.appendChild(_scrollArrow);

//#1.3.2
// create selected data container
var _selectedData = document.createElement("div");
_selectedData.setAttribute("id", "kly-adons-data-selected");
_body.appendChild(_selectedData);

//#1.4
// create footer
var _footer = document.createElement("div");
_footer.setAttribute("class", "footer");
_mainWrapper.appendChild(_footer);

//#1.4.1
// create msg wrapper
var _dmpMsg = document.createElement("div");
_dmpMsg.setAttribute("id", "dmp-tracker-status");
_footer.appendChild(_dmpMsg);

//#1.4.1.1
//success 
var _success = document.createElement("span");
_success.setAttribute("class", "success");
_success.innerHTML = `<p>dmp trakcer found, all is well</p> 👍`;
_dmpMsg.appendChild(_success);

//#1.4.1.2
// error
var _error = document.createElement("span");
_error.setAttribute("class", "error");
_error.innerHTML = `<p>dmp trakcer not found</p> 😪`;
_dmpMsg.appendChild(_error);

//#1.4.2
// button wrapper
var _btnWrapperFooter = document.createElement("div");
_btnWrapperFooter.setAttribute("class", "button-wrapper");
_footer.appendChild(_btnWrapperFooter);

//#1.4.2.1
// btn copy text
var _btnCopy = document.createElement("button");
_btnCopy.setAttribute("id", "kly-adons-copy");
_btnCopy.textContent = "copy text";
if (!_siInjected) {
	_btnWrapperFooter.appendChild(_btnCopy);
}

//#1.4.2.2
// btn apply text
var _btnApply = document.createElement("button");
_btnApply.setAttribute("id", "kly-adons-apply");
_btnApply.textContent = "apply";
if (!_siInjected) {
	_btnWrapperFooter.appendChild(_btnApply);
}

//#2
//overlay background
var _overlay = document.createElement("div");
_overlay.setAttribute("id", "kly-adons-overlay")
_overlay.setAttribute("title", "click to close")
if (!_siInjected) {
	document.body.appendChild(_overlay);
}

//#3 
// toast 
var _toast = document.createElement("div");
_toast.setAttribute("id", "kly-adons-toast");
if (!_siInjected) {
	document.body.appendChild(_toast);
}

var _toastMsg = document.createElement("div");
_toastMsg.setAttribute("id", "kly-adons-teast-message");
_toast.appendChild(_toastMsg);

var _inputCopy = document.createElement("input");
_inputCopy.setAttribute("type", "text");
_inputCopy.setAttribute("id", "kly-adons-input-copy");
_inputCopy.setAttribute("style", "height1px; width: 1px; opacity: 0; border: none;");
if (!_siInjected) {
	document.body.appendChild(_inputCopy);
}

var _style = document.createElement("style");
_style.textContent = `@import url("https://fonts.googleapis.com/css2?family=Fredoka+One&display=swap");.t5{-webkit-transition:cubic-bezier(0.075, 0.82, 0.165, 1) 0.5s;transition:cubic-bezier(0.075, 0.82, 0.165, 1) 0.5s}#kly-adons-main-wrapper{position:fixed;z-index:99999999999999999;width:40px;height:40px;background:#ffffff;border-radius:100% 0 0 100%;right:0;top:50%;-webkit-transform:translateY(-50%);transform:translateY(-50%);border:solid 1px #ffffff;-webkit-box-shadow:2px 2px 5px 5px #ddd6d650;box-shadow:2px 2px 5px 5px #ddd6d650;overflow:hidden}#kly-adons-main-wrapper #kly-adons-open{position:absolute;width:40px;height:40px;background:#fff;top:0px;z-index:99999;cursor:pointer}#kly-adons-main-wrapper #kly-adons-open img{width:80%;margin:10%}#kly-adons-main-wrapper.active{-webkit-animation:openPopup 1s forwards;animation:openPopup 1s forwards;cursor:initial}#kly-adons-main-wrapper.active .header{margin-top:20px}#kly-adons-main-wrapper.active .header .title{left:20px}#kly-adons-main-wrapper.active #kly-adons-open{display:none}#kly-adons-main-wrapper.remove{-webkit-animation:closePopup 1s forwards;animation:closePopup 1s forwards}#kly-adons-main-wrapper .header{position:relative;width:100%;height:50px;margin-top:-60px;-webkit-transition-property:all;transition-property:all;-webkit-transition-duration:.5s;transition-duration:.5s;-webkit-transition-delay:1s;transition-delay:1s;-webkit-transition-timing-function:cubic-bezier(0.68, -0.55, 0.265, 1.55);transition-timing-function:cubic-bezier(0.68, -0.55, 0.265, 1.55)}#kly-adons-main-wrapper .header .title{position:absolute;font-size:30px;line-height:30px;left:35px;top:10px;margin:0;font-family:'Fredoka One', cursive;color:#0f3460;opacity:.6;-webkit-transition-property:left;transition-property:left;-webkit-transition-duration:.5s;transition-duration:.5s;-webkit-transition-delay:1.2s;transition-delay:1.2s;-webkit-transition-timing-function:ease-in;transition-timing-function:ease-in}#kly-adons-main-wrapper .header .title span{color:#07689f}#kly-adons-main-wrapper .header input#kly-adons-search{position:relative;width:50%;margin:0 auto;font-size:15px;padding:10px;border:solid 1px #ececec;border-radius:0px 15px 15px 0px; color:#414141; text-align:left; outline:none} #kly-adons-main-wrapper .header #kly-adons-minimize{ position:absolute;right:35px;top:10px;font-size:30px;line-height:30px;color:#ececec;cursor:pointer}#kly-adons-main-wrapper .body{position:relative;display:-webkit-box;display:-ms-flexbox;display:flex;padding:20px 30px 10px;height:calc(100% - 160px);font-family:Arial, Helvetica, sans-serif}#kly-adons-main-wrapper .body.active div#kly-adons-data{width:75%}#kly-adons-main-wrapper .body.active div#kly-adons-data-selected{width:25%}#kly-adons-main-wrapper .body.active div#kly-adons-data-selected:before{display:block}#kly-adons-main-wrapper .body div#kly-adons-data{display:inline-block;width:100%;height:100%;overflow-y:scroll;-webkit-transition:all .5s ease-in-out;transition:all .5s ease-in-out}#kly-adons-main-wrapper .body div#kly-adons-data:before{content:"top of content";display:block;text-align:center;color:#797677;font-size:10px;padding-bottom:10px}#kly-adons-main-wrapper .body div#kly-adons-data:after{content:"end of content";display:block;text-align:center;color:#797677;font-size:10px;padding:10px}#kly-adons-main-wrapper .body div#kly-adons-data .scroll-down{position:absolute;z-index:9;left:0%;bottom:100px;background:#21212170;color:#fff;padding:5px 10px;border-radius:5px;font-size:12px;-webkit-transform:rotate(90deg);transform:rotate(90deg);-webkit-box-shadow:2px 1px 10px 5px #21212110;box-shadow:2px 1px 10px 5px #21212110;-webkit-animation:updownscroll 1s infinite;animation:updownscroll 1s infinite}#kly-adons-main-wrapper .body div#kly-adons-data .scroll-down i{margin-left:10px}#kly-adons-main-wrapper .body div#kly-adons-data .kly-adons-li{display:-webkit-inline-box;display:-ms-inline-flexbox;display:inline-flex}#kly-adons-main-wrapper .body div#kly-adons-data .kly-adons-li .kly-adons-item{display:-webkit-inline-box;display:-ms-inline-flexbox;display:inline-flex;position:relative;padding:7.5px 20px;background:#ececec;border-radius:4px;margin:10px 5px 0px 0px;cursor:pointer; min-width: 50px;    justify-content: center;}#kly-adons-main-wrapper .body div#kly-adons-data .kly-adons-li .kly-adons-item .pixel-id{position:absolute;bottom:30px;width:100%;font-size:12px;left:0;-webkit-box-sizing:border-box;box-sizing:border-box;padding:0 10px;background:#fddb3a;overflow:hidden;text-align:center;border-radius:10px 10px 0 0;height:0px;-webkit-transition:all .1s ease-in-out;transition:all .1s ease-in-out}#kly-adons-main-wrapper .body div#kly-adons-data .kly-adons-li .kly-adons-item:hover{background:#1089ff;color:#fff; border-radius : 0px 0px 10px 10px}#kly-adons-main-wrapper .body div#kly-adons-data .kly-adons-li .kly-adons-item:hover .pixel-id{height:30px;color:#212121;padding:10px; border-radius: 10px 10px 0px 0px;}#kly-adons-main-wrapper .body div#kly-adons-data .kly-adons-li .kly-adons-item.selected{cursor:not-allowed;color:#d5d1d2;pointer-events:none}#kly-adons-main-wrapper .body div#kly-adons-data::-webkit-scrollbar{display:none}#kly-adons-main-wrapper .body div#kly-adons-data-selected{width:0%;display:inline-block;height:100%}#kly-adons-main-wrapper .body div#kly-adons-data-selected:before{content:"click to remove";display:none;text-align:center;width:100%;margin:0px 0px 20px}#kly-adons-main-wrapper .body div#kly-adons-data-selected .kly-adons-item{text-transform: lowercase;display:-webkit-inline-box;display:-ms-inline-flexbox;display:inline-flex;position:relative;padding:7.5px 20px;background:#fddb3a;border-radius:4px;margin:10px 5px 0px 0px;cursor:pointer; min-width: 50px; justify-content: center;}#kly-adons-main-wrapper .body div#kly-adons-data-selected .kly-adons-item .pixel-id{position:absolute;bottom:30px;width:100%;font-size:12px;left:0;-webkit-box-sizing:border-box;box-sizing:border-box;padding:0 10px;background:#f02727;overflow:hidden;text-align:center;border-radius:10px 10px 0 0;height:0px;-webkit-transition:all .1s ease-in-out;transition:all .1s ease-in-out}#kly-adons-main-wrapper .body div#kly-adons-data-selected .kly-adons-item:hover{background:#212121;color:#fddb3a; border-radius:0px 0px 10px 10px;}#kly-adons-main-wrapper .body div#kly-adons-data-selected .kly-adons-item:hover .pixel-id{height:30px;color:#fff;padding:10px; border-radius: 10px 10px 0px 0px}#kly-adons-main-wrapper .footer{position:relative;height:50px;width:100%;padding:0 35px;-webkit-box-sizing:border-box;box-sizing:border-box;display:-webkit-box;display:-ms-flexbox;display:flex}#kly-adons-main-wrapper .footer #dmp-tracker-status{-ms-flex-item-align:center;-ms-grid-row-align:center;align-self:center;font-family:Arial, Helvetica, sans-serif;font-size:14px}#kly-adons-main-wrapper .footer #dmp-tracker-status span{display:block}#kly-adons-main-wrapper .footer #dmp-tracker-status span p{font-style:italic;margin:0px 10px 0px 0px;float:left}#kly-adons-main-wrapper .footer #dmp-tracker-status .success{color:green;display:none}#kly-adons-main-wrapper .footer #dmp-tracker-status .success.active{display:block}#kly-adons-main-wrapper .footer #dmp-tracker-status .error{display:none;color:red}#kly-adons-main-wrapper .footer #dmp-tracker-status .error.active{display:block}#kly-adons-main-wrapper .footer .button-wrapper{position:absolute;right:35px;-ms-flex-item-align:center;-ms-grid-row-align:center;align-self:center}#kly-adons-main-wrapper .footer .button-wrapper button{font-size:15px;height:40px;border:none;padding:5px 20px;border-radius:5px;cursor:pointer}#kly-adons-main-wrapper .footer .button-wrapper button#kly-adons-apply{background:#1089ff;color:#fff;border:solid 2px #0966c430}#kly-adons-main-wrapper .footer .button-wrapper button#kly-adons-copy{background:#ececec;color:#b1abab}#kly-adons-overlay{position:fixed;z-index:999999999;background:#21212120;right:0;-webkit-transition:all .25s ease-in-out;transition:all .25s ease-in-out;-webkit-transform:translate(-50%, 50%);transform:translate(-50%, 50%);border-radius:100%}#kly-adons-overlay.active{-webkit-animation:openOverlay;animation:openOverlay;-webkit-animation-duration:1s;animation-duration:1s;-webkit-animation-fill-mode:forwards;animation-fill-mode:forwards}#kly-adons-overlay.remove{-webkit-animation:closeOverlay;animation:closeOverlay;-webkit-animation-duration:1s;animation-duration:1s;-webkit-animation-fill-mode:forwards;animation-fill-mode:forwards}#kly-adons-toast{position:fixed;z-index:9999999999999999;background:#212121;bottom:-100%;left:30px;width:300px;min-height:75px;border-radius:15px;-webkit-transition:bottom .5s ease-in-out;transition:bottom .5s ease-in-out;cursor:pointer}#kly-adons-toast.active{bottom:30px}#kly-adons-toast.success #kly-adons-teast-message:before{content:"";position:absolute;width:10px;height:10px;background:lime;left:25px;top:50%;-webkit-transform:translate(-50%, -50%);transform:translate(-50%, -50%);border-radius:100px}#kly-adons-toast.success #kly-adons-teast-message .title{color:lime}#kly-adons-toast.error #kly-adons-teast-message:before{content:"";position:absolute;width:10px;height:10px;background:#ff4b5c;left:25px;top:50%;-webkit-transform:translate(-50%, -50%);transform:translate(-50%, -50%);border-radius:100px}#kly-adons-toast.error #kly-adons-teast-message .title{color:#ff4b5c}#kly-adons-toast:hover{bottom:30px}#kly-adons-toast #kly-adons-teast-message{position:relative;width:100%;display:block;-webkit-box-sizing:border-box;box-sizing:border-box;padding:20px 20px 20px 50px;color:#fff;font-family:'Courier New', Courier, monospace}#kly-adons-toast #kly-adons-teast-message .title{display:block;margin-bottom:5px}@-webkit-keyframes updownscroll{0%{bottom:100px}20%{bottom:100px}50%{bottom:50px}80%{bottom:100px}100%{bottom:100px}}@keyframes updownscroll{0%{bottom:100px}20%{bottom:100px}50%{bottom:50px}80%{bottom:100px}100%{bottom:100px}}@-webkit-keyframes openOverlay{0%{opacity:0;bottom:0;width:10px;height:10px}49%{opacity:0;bottom:50%;left:50%;width:10px;height:10px}50%{opacity:1;bottom:50%;left:50%;width:10px;height:10px}70%{opacity:1;bottom:0;left:50%;width:100vh;height:100vh;-webkit-transform:translate(-50%, 0%);transform:translate(-50%, 0%);border-radius:100px}100%{opacity:1;bottom:0;left:50%;width:100%;height:100vh;-webkit-transform:translate(-50%, 0%);transform:translate(-50%, 0%);border-radius:0px}}@keyframes openOverlay{0%{opacity:0;bottom:0;width:10px;height:10px}49%{opacity:0;bottom:50%;left:50%;width:10px;height:10px}50%{opacity:1;bottom:50%;left:50%;width:10px;height:10px}70%{opacity:1;bottom:0;left:50%;width:100vh;height:100vh;-webkit-transform:translate(-50%, 0%);transform:translate(-50%, 0%);border-radius:100px}100%{opacity:1;bottom:0;left:50%;width:100%;height:100vh;-webkit-transform:translate(-50%, 0%);transform:translate(-50%, 0%);border-radius:0px}}@-webkit-keyframes closeOverlay{100%{opacity:0;bottom:0;width:10px;height:10px}51%{opacity:0;bottom:50%;left:50%;width:10px;height:10px}35%{opacity:0;bottom:50%;left:50%;width:10px;height:10px;border-radius:100%}30%{opacity:1;bottom:0;left:50%;width:100vh;height:100vh;-webkit-transform:translate(-50%, 0%);transform:translate(-50%, 0%);border-radius:100px}0%{opacity:1;bottom:0;left:50%;width:100%;height:100vh;-webkit-transform:translate(-50%, 0%);transform:translate(-50%, 0%);border-radius:0px}}@keyframes closeOverlay{100%{opacity:0;bottom:0;width:10px;height:10px}51%{opacity:0;bottom:50%;left:50%;width:10px;height:10px}35%{opacity:0;bottom:50%;left:50%;width:10px;height:10px;border-radius:100%}30%{opacity:1;bottom:0;left:50%;width:100vh;height:100vh;-webkit-transform:translate(-50%, 0%);transform:translate(-50%, 0%);border-radius:100px}0%{opacity:1;bottom:0;left:50%;width:100%;height:100vh;-webkit-transform:translate(-50%, 0%);transform:translate(-50%, 0%);border-radius:0px}}@-webkit-keyframes openPopup{0%{width:40px;height:40px;right:0}40%{width:20px;height:80px;right:0;border-radius:100% 0 0 100%}45%{width:40px;height:40px;border-radius:100%}50%{width:40px;height:40px;border-radius:100%;border:solid 1px #cfcece;-webkit-box-shadow:2px 2px 5px 5px #ddd6d650;box-shadow:2px 2px 5px 5px #ddd6d650;right:50%;-webkit-transform:translate(50%, -50%);transform:translate(50%, -50%)}65%{width:20px;height:20px;border-radius:100%;border:solid 1px #cfcece;-webkit-box-shadow:2px 2px 5px 5px #ddd6d650;box-shadow:2px 2px 5px 5px #ddd6d650;right:50%;-webkit-transform:translate(50%, -50%);transform:translate(50%, -50%)}75%{width:70px;height:70px;border-radius:10px;border:solid 1px #cfcece;-webkit-box-shadow:2px 2px 5px 5px #ddd6d650;box-shadow:2px 2px 5px 5px #ddd6d650;right:50%;-webkit-transform:translate(50%, -50%);transform:translate(50%, -50%)}100%{width:70%;height:80vh;border-radius:10px;border:solid 1px #cfcece;-webkit-box-shadow:2px 2px 5px 5px #ddd6d650;box-shadow:2px 2px 5px 5px #ddd6d650;right:50%;-webkit-transform:translate(50%, -50%);transform:translate(50%, -50%)}}@keyframes openPopup{0%{width:40px;height:40px;right:0}40%{width:20px;height:80px;right:0;border-radius:100% 0 0 100%}45%{width:40px;height:40px;border-radius:100%}50%{width:40px;height:40px;border-radius:100%;border:solid 1px #cfcece;-webkit-box-shadow:2px 2px 5px 5px #ddd6d650;box-shadow:2px 2px 5px 5px #ddd6d650;right:50%;-webkit-transform:translate(50%, -50%);transform:translate(50%, -50%)}65%{width:20px;height:20px;border-radius:100%;border:solid 1px #cfcece;-webkit-box-shadow:2px 2px 5px 5px #ddd6d650;box-shadow:2px 2px 5px 5px #ddd6d650;right:50%;-webkit-transform:translate(50%, -50%);transform:translate(50%, -50%)}75%{width:70px;height:70px;border-radius:10px;border:solid 1px #cfcece;-webkit-box-shadow:2px 2px 5px 5px #ddd6d650;box-shadow:2px 2px 5px 5px #ddd6d650;right:50%;-webkit-transform:translate(50%, -50%);transform:translate(50%, -50%)}100%{width:70%;height:80vh;border-radius:10px;border:solid 1px #cfcece;-webkit-box-shadow:2px 2px 5px 5px #ddd6d650;box-shadow:2px 2px 5px 5px #ddd6d650;right:50%;-webkit-transform:translate(50%, -50%);transform:translate(50%, -50%)}}@-webkit-keyframes closePopup{100%{width:40px;height:40px;right:0}60%{width:20px;height:80px;right:0;border-radius:100% 0 0 100%}55%{width:40px;height:40px;border-radius:100%}50%{width:40px;height:40px;border-radius:100%;border:solid 1px #cfcece;-webkit-box-shadow:2px 2px 5px 5px #ddd6d650;box-shadow:2px 2px 5px 5px #ddd6d650;right:50%;-webkit-transform:translate(50%, -50%);transform:translate(50%, -50%)}35%{width:20px;height:20px;border-radius:100%;border:solid 1px #cfcece;-webkit-box-shadow:2px 2px 5px 5px #ddd6d650;box-shadow:2px 2px 5px 5px #ddd6d650;right:50%;-webkit-transform:translate(50%, -50%);transform:translate(50%, -50%)}25%{width:70px;height:70px;border-radius:10px;border:solid 1px #cfcece;-webkit-box-shadow:2px 2px 5px 5px #ddd6d650;box-shadow:2px 2px 5px 5px #ddd6d650;right:50%;-webkit-transform:translate(50%, -50%);transform:translate(50%, -50%)}0%{width:70%;height:80vh;border-radius:10px;border:solid 1px #cfcece;-webkit-box-shadow:2px 2px 5px 5px #ddd6d650;box-shadow:2px 2px 5px 5px #ddd6d650;right:50%;-webkit-transform:translate(50%, -50%);transform:translate(50%, -50%)}}@keyframes closePopup{100%{width:40px;height:40px;right:0}60%{width:20px;height:80px;right:0;border-radius:100% 0 0 100%}55%{width:40px;height:40px;border-radius:100%}50%{width:40px;height:40px;border-radius:100%;border:solid 1px #cfcece;-webkit-box-shadow:2px 2px 5px 5px #ddd6d650;box-shadow:2px 2px 5px 5px #ddd6d650;right:50%;-webkit-transform:translate(50%, -50%);transform:translate(50%, -50%)}35%{width:20px;height:20px;border-radius:100%;border:solid 1px #cfcece;-webkit-box-shadow:2px 2px 5px 5px #ddd6d650;box-shadow:2px 2px 5px 5px #ddd6d650;right:50%;-webkit-transform:translate(50%, -50%);transform:translate(50%, -50%)}25%{width:70px;height:70px;border-radius:10px;border:solid 1px #cfcece;-webkit-box-shadow:2px 2px 5px 5px #ddd6d650;box-shadow:2px 2px 5px 5px #ddd6d650;right:50%;-webkit-transform:translate(50%, -50%);transform:translate(50%, -50%)}0%{width:70%;height:80vh;border-radius:10px;border:solid 1px #cfcece;-webkit-box-shadow:2px 2px 5px 5px #ddd6d650;box-shadow:2px 2px 5px 5px #ddd6d650;right:50%;-webkit-transform:translate(50%, -50%);transform:translate(50%, -50%)}}button#kly-button-reload-dmp-api.active { display: block; } button#kly-button-reload-dmp-api { position: relative; align-self: center; margin: 50px auto; border: none; border-radius: 10px; padding: 10px 30px; color: #fff; background: -webkit-linear-gradient(top, #1089ff, #2038e9); box-shadow: 1px 12px 10px -10px #1089ff80; display: none; cursor: pointer; transition: all .25s ease; } button#kly-button-reload-dmp-api:hover { margin: 53px auto 47px; box-shadow: 1px 9px 10px -10px #1089ff80; }select#kly-adons-select {box-sizing: border-box;position: relative; font-size: 15px; border: none; padding: 10px 25px; text-align: center; width: 45%; border-radius: 15px 0 0 15px; text-transform: lowercase; background: #ececec80;}div#kly-adons-filter-wrapper { position: relative; display: block; width: 50%; margin: 0 auto; }.kly-adons-parent-id{display:none;}`;
if(!_siInjected){
	document.body.appendChild(_style);
}

var _fontAwesome = document.createElement("script");
_fontAwesome.setAttribute("src", "https://kit.fontawesome.com/cdd298d5f0.js");
_fontAwesome.setAttribute("crossorigin", "anonymous");
if(!_siInjected){
	document.body.appendChild(_fontAwesome);
}

var _listjs = document.createElement("script");
_listjs.setAttribute("src", "//cdnjs.cloudflare.com/ajax/libs/list.js/1.5.0/list.min.js");
if(!_siInjected){
	document.body.appendChild(_listjs);
}

var _script = document.createElement("script");
_script.textContent = `
const _mainWrapper = document.getElementById("kly-adons-main-wrapper");
const _overlayWrapper = document.getElementById("kly-adons-overlay");
const _klySelectAdons = document.getElementById("kly-adons-select");
const _klySearchAdons = document.getElementById("kly-adons-search");
const _klyMinimizeAdons = document.getElementById("kly-adons-minimize");
const _klyOpenAdons = document.getElementById("kly-adons-open");
const _klyApplyButton = document.getElementById("kly-adons-apply");
const _klyCopyButton = document.getElementById("kly-adons-copy");
const _klyToastWrapper = document.getElementById("kly-adons-toast");
const _klyToastMsg = document.getElementById("kly-adons-teast-message");
const _klyAdonsBodyContent = document.getElementById("kly-adons-body-content");
const _klyAdonsFooterMsg = document.getElementById("dmp-tracker-status");
const _klyCOpyInput = document.getElementById("kly-adons-input-copy");
const _klyRelaodDmpItem = document.getElementById("kly-button-reload-dmp-api");


const _klyAdonsDataWrapper = document.getElementById("kly-adons-data");
const _klyAdonsDataSelectedWrapper = document.getElementById("kly-adons-data-selected");

//
var _klyAdonsSelectedArray = [];
var _klyAdonsListjsData = null;
var _klyAdonsListjsDataParentCategory = [];

_bootExt();

function _bootExt() {
	_fetchData();
	_klyOpenAdons.addEventListener("click", _openPopupExt);
	_klyMinimizeAdons.addEventListener("click", _minimizePopupExt);
	_overlayWrapper.addEventListener("click", _minimizePopupExt);

	_klyApplyButton.addEventListener("click", _klyApplyEvent);
	_klyCopyButton.addEventListener("click", _klyCopyEvent);
	_klyRelaodDmpItem.addEventListener("click", _fetchData);
	_klyAdonsDataSelectedWrapper.addEventListener("mouseover", _klyAdonsClearSearch);
}

function _klyAdonsClearSearch() {
	//_klySearchAdons.value = "";
	_klyAdonsListjsData.search(_klySelectAdons.value);
}

function _openPopupExt() {
	_mainWrapper.classList.add("active");
	_mainWrapper.classList.remove("remove");
	_overlayWrapper.classList.add("active");
	_overlayWrapper.classList.remove("remove");
	_klyApplyButton.disabled = false;

	_klyAdonsInputCheck();

	//normalize button 

	// _klySearchAdons.focus();
}

function _minimizePopupExt() {
	_mainWrapper.classList.add("remove")
	_mainWrapper.classList.remove("active")
	_overlayWrapper.classList.remove("active");
	_overlayWrapper.classList.add("remove");
}

function _klyAdonsOpenToast(autoclose, html, status) {
	_klyToastWrapper.classList.add(status);
	_klyToastMsg.innerHTML = "";
	_klyToastMsg.innerHTML = html;
	_klyToastWrapper.classList.add("active");
	setTimeout(() => {
		_klyAdonsCloseToast();
	}, 5000);

	if (autoclose) {
		_minimizePopupExt();
	}
}

function _klyAdonsCloseToast() {
	_klyToastWrapper.setAttribute("class", "")
}

function _klyApplyEvent() {
	var _ifNullData =_klyGenerateSelectedItem();
	var html = (_ifNullData == "" ) ? \`<span class="title">error</span>no dmp trakcer\` :\`<span class="title">success</span>dmp success injected to craetive!\`;
	var _status = (_ifNullData == "") ? "error" : "success";
	var _autoclose = (_ifNullData == "") ? false : true;

	_klyAdonsOpenToast(_autoclose, html, _status);
	_klyAdonsSetTargetField(_ifNullData);
}

function _klyCopyEvent() {
	var _ifNullData =_klyGenerateSelectedItem();
	
	document.getElementById("kly-adons-input-copy").value = _ifNullData;
	_klyCOpyInput.select();
	document.execCommand("copy");

	var html = (_ifNullData == "" ) ? \`<span class="title">error</span>no dmp tracker\` : \`<span class="title">success copy</span>copy  \${_klyCOpyInput.value}\`;
	var _status = (_ifNullData == "") ? "error" : "success";
	var _autoclose = (_ifNullData == "") ? false : true;

	_klyAdonsOpenToast(_autoclose, html, _status)
}

function _klyGenerateSelectedItem() {
	var data = "";
	_klyAdonsSelectedArray.forEach(function(el, i){
		if (data == "") {
			data = el;
		}else{
			data += \`,\${el}\`;
		}
	})

	return data;
}

function _addItemDropdown(_item) {
	var _id = (_item == "all") ? "" : _item.id;
	var _name = (_item == "all") ? "show all" : _item.category;
	var _option = document.createElement("option");
	_option.setAttribute("value", _id);
	if (_item == "all") {
		_option.setAttribute("selected","selected");
	}
	_option.textContent = _name;
	_klySelectAdons.appendChild(_option);
}


function _fetchData() {
	fetch("https://www.newshub.id/api/category-management/&token=06c0cb9bc610871859140e9c1c04808c&limit=1000")
	.then(res => res.json())
	.then(res => {
		_addItemDropdown("all");
		res.data.map(dmp => {
			_klyAdonsGenerateItem(dmp);
			if (dmp.parent == "") {
				_klyAdonsListjsDataParentCategory.push(dmp);
				_addItemDropdown(dmp);
			}

		});
	})
	.then(()=>{
		var options = {
			valueNames: ['kly-adons-parent-id' ,'kly-adons-item','pixel-id' ]
		};

		// Init list
		_klyAdonsListjsData = new List('kly-adons-main-wrapper', options);
		_klyRelaodDmpItem.setAttribute("class", "");
		_klySelectAdons.addEventListener("change", function(){
			_klyAdonsListjsData.search(this.value);
		})
	})
	.catch((err) =>{
		console.log(err)
		_klyRelaodDmpItem.setAttribute("class", "active");
		var _x = setInterval(function () {
			if (_klyAdonsListjsData != null) {
				_klyRelaodDmpItem.classList.remove("active");
				clearInterval(_x);
			}
		}, 100);

	})
}

function _klyAdonsGenerateItem(item) {

	var _parentName = (item.parent == "") ? "no parent" : item.parent;
	var _parentId = (item.parent_id == 0) ? item.id : item.parent_id;
	var _li = document.createElement("li");
	_li.setAttribute("class", "kly-adons-li");

	var _span = document.createElement("span");
	_span.setAttribute("class", "kly-adons-item");
	_span.setAttribute("id", \`kly-adons-item-\${item.id}\`);
	_span.setAttribute("title", \`\${_parentName.toString().toLowerCase()}\`);
	_span.setAttribute("data-item-name", \`\${item.category_code}\`);
	_span.setAttribute("data-item-category", \`\${item.category}\`);
	_span.setAttribute("data-item-parentid", \`\${_parentId}\`);
	_span.setAttribute("data-item-pixelid", \`\${(item.pixel_id == null) ? "no pixel id" :item.pixel_id }\`);

	_span.textContent = item.category.toLowerCase();
	_span.addEventListener("click", _klyAdonsSelectItem);
	_li.appendChild(_span);


	var _div = document.createElement("div");
	_div.setAttribute("class", "pixel-id");
	_div.textContent = (item.pixel_id == null) ? "no pixel id" :item.pixel_id ;
	_span.appendChild(_div);

	var _divParentid = document.createElement("div");
	_divParentid.setAttribute("class", "kly-adons-parent-id");
	_divParentid.textContent = (item.parent_id == 0) ?item.id : item.parent_id;
	_span.appendChild(_divParentid);
	

	_klyAdonsDataWrapper.querySelector(".list").appendChild(_li);
}

function _klyAdonsSelectItem() {

	this.classList.add("selected");
	var _name = this.getAttribute("data-item-name");

	_klyAdonsSelectedArray.push(_name);

	_klyCeckSelectedArray();

	var _span = document.createElement("span");
	_span.setAttribute("class", "kly-adons-item");
	_span.setAttribute("id", \`\${this.getAttribute("id")}\`);
	_span.setAttribute("title", \`\${this.getAttribute("title").toString().toLowerCase()}\`);
	_span.setAttribute("data-item-name", \`\${this.getAttribute("data-item-name")}\`);

	_span.addEventListener("click", _klyAdonsRemoveSelectedItem);
	_span.textContent = this.getAttribute("data-item-category");

	var _div = document.createElement("div");
	_div.setAttribute("class", "pixel-id");
	_div.textContent = this.getAttribute("data-item-pixelid");
	_span.appendChild(_div);

	_klyAdonsDataSelectedWrapper.appendChild(_span);

}

function _klyAdonsRemoveSelectedItem() {
	var _index =  _klyAdonsSelectedArray.indexOf(this.textContent);
	_klyAdonsSelectedArray.splice(_index, 1);

	var _id = this.getAttribute("id");
	_klyAdonsDataWrapper.querySelector(\`.list li #\${_id}\`).classList.remove("selected");

	this.remove();

	_klyCeckSelectedArray();

}

function _klyCeckSelectedArray() {
	if(_klyAdonsSelectedArray.length == 0){
		_klyAdonsBodyContent.classList.remove("active");
	}else{
		_klyAdonsBodyContent.classList.add("active");
	}
}

//input check

// check dmp tracker field
function _klyAdonsCheckDmpFieldTracker() {
	var _target = null;
	var _x  = (document.querySelector(".tab-content")) ? document.querySelectorAll(".tab-content .field-label") : document.querySelectorAll(".drawer-content .field-label");
	_x.forEach(function(el, i){

		el.querySelectorAll("span").forEach(function (_el, _i) {

			if (_el.textContent == "DMP Category" || _el.textContent == "DMPCategory") {
				_target = el;
			}

		})

	})

	return _target;

}

//get value
function _klyAdonsGetTargetField() {
	var _tarEl = _klyAdonsCheckDmpFieldTracker();
	var _parentSibling = _tarEl.parentElement.parentElement.nextElementSibling;
	var _value = (_parentSibling.querySelector("input")) ? _parentSibling.querySelector("input").value : _parentSibling.querySelector(".CodeMirror .CodeMirror-line span").textContent;

	return _value;
}

function _klyAdonsSetTargetField(value) {
	var _tarEl = _klyAdonsCheckDmpFieldTracker();
	var _parentSibling = _tarEl.parentElement.parentElement.nextElementSibling;

	if (_parentSibling.querySelector("input")) {
		_parentSibling.querySelector("input").value = value;
	}else{
		_parentSibling.querySelector(".CodeMirror .CodeMirror-line span").textContent = value;
	}
}


function _klyAdonsInputCheck() {
	var _check = Boolean(_klyAdonsCheckDmpFieldTracker());
	_klyAdonsFooterMsg.querySelector(".success").classList.remove("active");
	_klyAdonsFooterMsg.querySelector(".error").classList.remove("active");

	if(_check){
		//msg true
		_klyAdonsFooterMsg.querySelector(".success").classList.add("active");
	}else{
		//msg false
		_klyAdonsFooterMsg.querySelector(".error").classList.add("active");
		_klyApplyButton.disabled = true;

	}
}

`;
if (!_siInjected) {
	document.body.appendChild(_script);
}
